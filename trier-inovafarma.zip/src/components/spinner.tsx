import { Loader2 } from "lucide-react";

export function Spinner({ className }: { className?: string }) {
  return (
    <Loader2 className={`animate-spin text-blue-500 ${className}`} size={48} />
  );
}
